// Задание 5
/*function countVowels(str) {
  const vowels = ['a', 'e', 'i', 'o', 'u'];
  let count = 0;
  for (let i = 0; i < str.length; i++) {
    if (vowels.includes(str[i].toLowerCase())) {
      count++;
    }
  }
  return count;
}
console.log(countVowels("Celebration")); // 5
console.log(countVowels("Palm")); // 1*/

// Задание 5.2
/*function removeABC(str) {
  // Проверка на наличие символов 'a', 'b', 'c'
  if (/[abc]/i.test(str)) {
    // Удаление символов 'a', 'b', 'c' из строки
    return str.replace(/[abc]/gi, '');
  } else {
    return null;
  }
}

// Примеры использования
console.log(removeABC("This might be a bit hard")); // "This might e it hrd"
console.log(removeABC("hello world!")); // null*/

//Задание 7
  /*function reverseObject(obj) {
  const result = {};
  for (const key in obj) {
    result[obj[key]] = key;
  }
  return result;
}

const input = {red: "#FF0000", green: "#00FF00", white: "#FFFFFF"};
const output = reverseObject(input);
console.log(output); // {"#FF0000":"red","#00FF00":"green","#FFFFFF":"white"}*/
//Задание 8
/*function calculateDifference(items, insurance) {
let totalValue = Object.values(items).reduce((acc, cur) => acc + cur, 0);
return totalValue > insurance ? totalValue - insurance : 0;
}

// Приклади використання:
console.log(calculateDifference({ "baseball bat": 20 }, 5)); // 15
console.log(calculateDifference({ skate: 10, painting: 20 }, 19)); // 11
console.log(calculateDifference({ skate: 200, painting: 200, shoes: 1 }, 400)); // 1*/

//Задание 9
/*function doesBrickFit(a, b, c, w, h) {
  // перевірка розмірів цегли та отвору
  if ((a <= w && b <= h) || (b <= w && a <= h)) {
    return true; // цегла поміщається
  } else if ((a <= w && c <= h) || (c <= w && a <= h)) {
    return true; // цегла поміщається
  } else if ((b <= w && c <= h) || (c <= w && b <= h)) {
    return true; // цегла поміщається
  } else {
    return false; // цегла не поміщається
  }
}
console.log(doesBrickFit(1, 1, 1, 1, 1)); // true
console.log(doesBrickFit(1, 2, 1, 1, 1)); // true
console.log(doesBrickFit(1, 2, 2, 1, 1)); // false*/

//Задание 10
/*const filename = 'c:\\WebServers\\home\\testsite\\www\\myfile.txt';
const basename = filename.split('\\').pop(); // отримуємо ім'я файлу разом з розширенням
const nameWithoutExt = basename.split('.')[0]; // отримуємо ім'я файлу без розширення
console.log(nameWithoutExt); // 'myfile'*/

//Задание 13
/*function transformString(inputString) {
  let words = inputString.split(' ');

  // Перша літера першого слова залишається у верхньому регістрі
  words[0] = words[0].charAt(0).toUpperCase() + words[0].slice(1);

  // Застосування правил трансформації до кожного слова
  words = words.map(word => {
    // Всі слова у нижньому регістрі, крім першої літери першого слова
    if (word !== words[0]) {
      word = word.toLowerCase();
    }
    // Усі посилання у словах замінюються на "[посилання заборонено]"
    word = word.replace(/(https?:\/\/[^\s]+)/gi, '[посилання заборонено]');
    // Всі email замінюються на "[контакти заборонені]"
    word = word.replace(/(\S+@\S+\.\S+)/gi, '[контакти заборонені]');
    // Усі слова довжини понад 3 символи, що містять лише цифри, видаляються
    if (word.length > 3 && /^\d+$/.test(word)) {
      word = '';
    }
    return word;
  });

  // Видалення порожніх елементів
  words = words.filter(word => word !== '');

  // Формування вихідного рядка
  const outputString = words.join(' ');

  // Перевірка на довжину рядка і запуск функції alert у разі необхідності
  if (outputString.length > inputString.length) {
    setInterval(() => {
      if (confirm('Чи потрібна нам допомога?')) {
        alert('Зверніться до нашого спеціаліста!');
      }
    }, 5000);
  }

  return outputString;
}
// Приклад
const inputString = 'Welcome to my website! My email is john@example.com and my website is https://example.com.';
const outputString = transformString(inputString);
console.log(outputString); // "Welcome to my */

  //Задание 15
// Запросити користувача ввести фразу
/*const phrase = prompt('Введіть фразу:');

// Розділити фразу на масив слів
const words = phrase.split(' ');

// Створити список ul
const ul = document.createElement('ul');

// Пройтися по масиву слів та додати кожне слово у список ul
words.forEach((word, index) => {
  const li = document.createElement('li');
  li.textContent = word;
  ul.appendChild(li);

  // Якщо це перше слово, змінити його на uppercase
  if (index === 0) {
    li.textContent = li.textContent.toUpperCase();
  }

  // Якщо це останні 2 слова, змінити їх на lowercase
  if (index === words.length - 2 || index === words.length - 1) {
    li.textContent = li.textContent.toLowerCase();
  }
});

// Додати список ul на сторінку
document.body.appendChild(ul);

// Знайти кількість літер "а" у фразі та вивести у вікно alert
const countA = phrase.split('a').length - 1;
alert(`Кількість літер "а" у фразі: ${countA}`);

// Створити таймер на 5 хвилин (300000 мс), щоб викликати функцію "ping"
const timer = setTimeout(ping, 300000);

// Функція "ping", що спливає повідомлення "Ви ще тут?"
function ping() {
  if (confirm('Ви ще тут?')) {
    // Якщо користувач ще на сторінці, зупинити таймер і розпочати його знову
    clearTimeout(timer);
    setTimeout(ping, 300000);
  } else {
    // Якщо користувач відвідав сторінку, закрити сторінку
    window.close();
  }
}*/

//Задание 16
/*
let password = prompt("Enter a password");
let minLength = 6;
let maxLength = 20;
let underscoreCount = 1;
let uppercaseCount = 2;
let maxDigitCount = 5;

let isValid = true;
let underscoreRegex = /_/g;
let uppercaseRegex = /[A-Z]/g;
let digitRegex = /\d/g;
let consecutiveDigitRegex = /\d{2}/g;
if (password.length < minLength || password.length > maxLength) {
  isValid = false;
}
if ((password.match(underscoreRegex) || []).length !== underscoreCount) {
  isValid = false;
}
if ((password.match(uppercaseRegex) || []).length < uppercaseCount) {
  isValid = false;
}
if ((password.match(digitRegex) || []).length > maxDigitCount) {
  isValid = false;
}
if (password.match(consecutiveDigitRegex)) {
  isValid = false;
}
if (isValid) {
  alert("Password is valid");
} else {
  alert("Password is invalid");
}*/


